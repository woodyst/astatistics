use DBIx::MyParsePP;
use YAML;

my $parser = DBIx::MyParsePP->new();

my $query = $parser->parse("SELECT 1");

print Dump($query);
print $query->toString();
