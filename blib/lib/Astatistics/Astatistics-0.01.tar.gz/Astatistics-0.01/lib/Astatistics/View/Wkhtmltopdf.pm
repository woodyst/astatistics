package Astatistics::View::Wkhtmltopdf;
use Moose;

extends 'Catalyst::View::Wkhtmltopdf';

__PACKAGE__->meta->make_immutable();


=head1 NAME

Astatistics::View::Wkhtmltopdf - Catalyst Wkhtmltopdf View

=head1 SYNOPSIS

See L<Astatistics>

=head1 DESCRIPTION

Catalyst Wkhtmltopdf View.

=head1 AUTHOR

,,,

=head1 LICENSE

This library is free software, you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

1;
