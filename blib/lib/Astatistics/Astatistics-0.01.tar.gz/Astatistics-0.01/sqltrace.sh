#!/bin/bash

export DBIC_TRACE=1
