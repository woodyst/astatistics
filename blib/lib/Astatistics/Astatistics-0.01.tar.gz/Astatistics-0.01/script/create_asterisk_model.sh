#!/bin/bash

script/astatistics_create.pl model Asterisk DBIC::Schema Asterisk::Schema create=static dbi:mysql:dbname=asterisk root 4321
