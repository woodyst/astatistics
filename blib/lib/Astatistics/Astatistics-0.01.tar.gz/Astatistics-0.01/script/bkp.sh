#!/bin/bash

cd ..
mv Astatistics.tar.gz Astatistics.tar.gz.old
tar -czvf Astatistics.tar.gz Astatistics/
